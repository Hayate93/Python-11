class GameClass:
    def __init__(self):
        print("Game class is instantiated")
    def start(self):
        print("Game is started")
    def hit(self,hit_strength):
        print(f"Hit performed with strength {hit_strength}")

